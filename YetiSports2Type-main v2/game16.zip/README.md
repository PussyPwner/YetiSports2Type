# YetiSports2Type
YetiSports2 game easy interpretation
https://www.nashvail.me/blog/canvas-image
